     <div class="span3" id="sidebar">
                    <ul class="nav nav-list bs-docs-sidenav nav-collapse collapse">
                        <li> <a href="dashboard.php"><i class="icon-chevron-right"></i><i class="icon-home"></i>&nbsp;Dashboard</a> </li>
						<li>
                            <a href="subjects.php"><i class="icon-chevron-right"></i><i class="icon-list-alt"></i> Subject</a>
                        </li>
						<li>
                            <a href="class.php"><i class="icon-chevron-right"></i><i class="icon-group"></i> Class</a>
                        </li>
						<li>
                            <a href="admin_user.php"><i class="icon-chevron-right"></i><i class="icon-user"></i> Admin Users</a>
                        </li>
						<li>
                            <a href="department.php"><i class="icon-chevron-right"></i><i class="icon-building"></i> Department</a>
                        </li>
						<li>
                            <a href="students.php"><i class="icon-chevron-right"></i><i class="icon-group"></i> Students</a>
                        </li>
						<li>
                            <a href="teachers.php"><i class="icon-chevron-right"></i><i class="icon-group"></i> Teachers</a>
                        </li>
						<li>
                            <a href="downloadable.php"><i class="icon-chevron-right"></i><i class="icon-download"></i> Downloadable Materials</a>
                        </li>
						<li>
                            <a href="assignment.php"><i class="icon-chevron-right"></i><i class="icon-upload"></i> Uploaded Assignments</a>
                        </li>
						<li  class="active">
                            <a href="content.php"><i class="icon-chevron-right"></i><i class="icon-file"></i> Content</a>
                        </li>
						<li>
                            <a href="user_log.php"><i class="icon-chevron-right"></i><i class="icon-file"></i> User Log</a>
                        </li>
						<li>
                            <a href="activity_log.php"><i class="icon-chevron-right"></i><i class="icon-file"></i> Activity Log</a>
                        </li>
						<li>
                            <a href="school_year.php"><i class="icon-chevron-right"></i><i class="icon-calendar"></i> School Year</a>
                        </li>
						<li class="">
                            <a href="calendar_of_events.php"><i class="icon-chevron-right"></i><i class="icon-calendar"></i>Calendar of Events</a>
                        </li>					
                    </ul>
					
					
				
                </div>